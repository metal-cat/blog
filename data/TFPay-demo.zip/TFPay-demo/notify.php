<?php
require_once 'TFPay.Conf.php';
require_once 'TFPay.Demo.php';

// 初始化
$demo = new TFPayDemo(
    TFPayConf::URL,     // API 地址
    TFPayConf::UID,     // 平台 UID
    TFPayConf::SECRET   // 平台密钥
);


// 回调参数以KV数组的形式输出
$notify = $demo->notify();


if( $notify )
{
    $json = $demo->json( $notify );
    $demo->log( $json );
    echo $json;
}
else
{
    echo json_encode( [
        'type'=>'error',
        'code'=>'UNKNOW',
        'msg'=>'非法操作'
    ] );
}
