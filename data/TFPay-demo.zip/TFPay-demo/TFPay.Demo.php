<?php

// 设置时区
date_default_timezone_set('Asia/Shanghai');

/**
 * 
 * @method TFPayDemo
 * @deprecated 唐博狐支付接口演示
 * 
 * ---------------------
 * 
 * @see create_trade    创建订单
 * @see query           订单查询
 * @see notify          回调
 * 
 * ---------------------
 * @author Metal Cat
 * @version 1.0
 * 
 */
class TFPayDemo
{
    private $url = '';
    private $uid = 0;
    private $secret = '';

    /**
     * @method __construct
     * @deprecated 构建
     * ----------------------
     * @param {String}  $url        API 地址
     * @param {Int}     $uid        平台 UID
     * @param {String}  $secret     平台密钥
     */
    public function __construct( $url = '', $uid = 0, $secret = '' )
    {
        $this->url = $url;
        $this->uid = $uid;
        $this->secret = $secret;    
    }


    /**
     * @method sign
     * @deprecated 签名
     * ------------------------
     * @param   {Int}     $trade_no     代码
     * @return  {String}                签名
     */
    private function sign( $trade_no )
    {
        return md5( md5( $trade_no ) . $this->secret );
    }


    /**
     * @method trade_no
     * @deprecated 订单号
     * ------------------------
     * @return {String}
     */
    private function trade_no()
    {
        return date( 'YmdHis' ) . rand( 1000, 9999 ) . rand( 1000, 9999 );
    }


    /**
     * @method create_trade
     * @deprecated 创建订单
     * ------------------------
     * @param {Int}    $amount     金额
     * @param {Int}    $type       支付类型: 0 = 支付宝; 1 = 微信
     */
    public function create_trade( $amount = 0, $type = 0 )
    {

        $trade_no = $this->trade_no();// 生产订单号
        $sign = $this->sign( $trade_no );// 生成签名

        // 参数
        $param = [
            'uid'       => $this->uid,
            'type'      => $type,
            'trade_no'  => $trade_no,
            'sign'      => $sign
        ];

        // 生成 URL
        $url = $this->url . '?' . http_build_query( $param );

        // 开始请求
        header( "location: $url" );
    }

    /**
     * @method query
     * @deprecated 查询订单
     * ------------------------
     * @param {String} $trade_no    订单号
     * @return {String} JSON 字符串
     */
    public function query( $trade_no )
    {
        $data = [
            'uid'       => $this->uid,
            'trade_no'  => $trade_no,
            'sign'      => $this->sign( $trade_no )
        ];
        return $this->request( $data );
    }


    /**
     * @method notify
     * @deprecated 回调
     * ------------------------
     * @return {Array}
     */
    public function notify()
    {
        // 过滤非法请求
        if ( empty( $_POST['type'] ) 
        || empty( $_POST['sign'] ) 
        || empty( $_POST['amount'] ) 
        || empty( $_POST['trade_no'] ) 
        || empty( $_POST['code'] ) ) return;

        
        $trade_no   = $_POST['trade_no'];
        $sign       = $_POST['sign'];
        
        // 验证签名
        if ( $sign != $this->sign( $trade_no ) )
        {
            $_POST['code'] = 'SIGN_ERROR';
            $_POST['msg'] = '签名错误';
        }
        return $_POST;
    }


    /**
     * @method
     * @param  [type] $data [写入的数据]
     * @return [type]       [description]
     */
    public function log( $data )
    {
        $filepath = __DIR__ . '/logs/log-' . date('Y-m-d') . '.log';
        $dirname = dirname( $filepath );
        if( !file_exists( $dirname ) )
        {
            @mkdir($dirname, 0777, true);
        }
        $fp = fopen( $filepath , 'a' );
        fwrite($fp , date('Y-m-d H:i:s ') . var_export( $data , true ) . "\r\n" );
        fclose($fp);
    }

    /**
     * @method json
     * @deprecated [仅用于测试] 提高中文可读性 ( PHP 5.4.0 + )
     * @param {Array} $data;
     * @return {String} JSON 字符串
     */
    public function json( $data = [] )
    {
        if (version_compare(PHP_VERSION,'5.4.0','<'))
        {
            $data = json_encode( $data );
            $data = preg_replace_callback( '/\\\u([0-9a-f]{4})/i', function( $matchs )
            {
                return iconv('UCS-2BE', 'UTF-8', pack('H4', $matchs[1] ) );
            }, $data);
        }else{
            $data = json_encode($data, JSON_UNESCAPED_UNICODE);
        }
        return $data;
    }
    
     
    /**
     * @method request
     * @deprecated 发起 CURL POST 请求
     * ------------------------
     * @param {Array}   $data       表单数据
     * @param {String}  $entry      API 入口文件 ( 此参数无需更改 )
     * @return {String} $result     JSON 字符串
     */
    private function request( $data, $entry = 'order' )
    {
        $curl = curl_init();
        curl_setopt( $curl, CURLOPT_URL, $this->url . '/api/' . $entry . '?uid=' . $this->uid );

        curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, 1 );
        curl_setopt( $curl, CURLOPT_AUTOREFERER, 1 );

        if ( strpos( $this->url, 'https://' ) === 0 )
        {
            curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, FALSE );
            curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, FALSE );
        }

        curl_setopt( $curl, CURLOPT_POST, 1 );
        curl_setopt( $curl, CURLOPT_POSTFIELDS, http_build_query( $data ) );
        curl_setopt( $curl, CURLOPT_HEADER, 0 );
        curl_setopt( $curl, CURLOPT_TIMEOUT, 10 );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );

        $result = curl_exec( $curl );
        if ( curl_errno( $curl ) )
        {
            curl_close( $curl );
            return json_encode(
                [
                    'type'  => 'error',
                    'code'  => 'UNKNOW',
                    'msg'   => '远程错误'
                ]
            );
        }

        curl_close( $curl );
        return $result;
    }
}
