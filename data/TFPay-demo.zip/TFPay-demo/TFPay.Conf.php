<?php
/**
 * @class TFPayConf
 */
class TFPayConf
{
    // App ID ( 即您在平台注册的 UID )
    const UID      = 0;

    // 密钥
    const SECRET   = ''; 

    // API请求地址
    const URL      = '';    

}