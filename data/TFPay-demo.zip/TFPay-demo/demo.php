<?php
require_once 'TFPay.Conf.php';
require_once 'TFPay.Demo.php';

// 初始化
$demo = new TFPayDemo(
    TFPayConf::URL,     // API 地址
    TFPayConf::UID,     // 平台 UID
    TFPayConf::SECRET   // 平台密钥
);


// 查单
if( !empty( $_GET['trade_no'] ) )
{
    $demo->query( $_GET['trade_no'] );
}
// 下单
else
{
    // 创建订单
    $amount = 100;  // 金额
    $type   = 0;    // 交易类型: 0 = 支付宝, 1 = 微信
    $demo->create_trade( $amount, $type );
}