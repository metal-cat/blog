# 1. 开始之前, 请先到平台看下文档
# 2. 配置 TFPay.Conf.php